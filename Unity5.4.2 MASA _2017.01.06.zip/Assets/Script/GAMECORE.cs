﻿using UnityEngine;
using System.Collections;

public class GAMECORE : MonoBehaviour {

    //二人プレイか
    public bool Two_Player;

    //落下死亡ライン
    public float DEAD_LINE;

    //加速減速値
    public float SPEED_UP_DOWN;

    //信号の真偽値
    public bool MOVE_BOOL;

    //信号を送るオブジェクト
    public GameObject Signal_Switch_Move;

    // Use this for initialization
    void Start () {

        

        PlayerController.Two_Play = Two_Player;

        PlayerController.DEAD_LINE = DEAD_LINE;

        PlayerController.SPEED_UP_DUWN = SPEED_UP_DOWN;
        
    }
	
	// Update is called once per frame
	void Update () {

        //信号を送るオブジェクトがあるか
        if (Signal_Switch_Move == null)
        {
            MOVE_BOOL = false;
        }
        else
        {
            MOVE_BOOL = Signal_Switch_Move.GetComponent<Switch_Move>().Action_Bool;
        }

        if (MOVE_BOOL == true)
        {
            Debug.Log("クリア");
        }
	
	}
}
