﻿using UnityEngine;
using System.Collections;

public class SavePoint : MonoBehaviour {

    public Vector3 Save_Point;

    //Rigidbody対応
    private Rigidbody rb;

    void Start () {

        rb = GetComponent<Rigidbody>();

        this.gameObject.tag = "SAVE_POINT";

        this.gameObject.layer = LayerMask.NameToLayer("SAVE_POINT");

        Save_Point = new Vector3(
                        this.transform.position.x,
                        this.transform.position.y + 5.0f,
                        this.transform.position.z
                        );

    }
	
	// Update is called once per frame
	void Update () {
	
	}

    //トリガーを使った判定（未解決）
    void OnTriggerEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Player_1") || other.gameObject.CompareTag("Player_2"))
        {
            PlayerController.SAVE_POINT = Save_Point;

            Debug.Log("HIT");
        }

        
    }
}
