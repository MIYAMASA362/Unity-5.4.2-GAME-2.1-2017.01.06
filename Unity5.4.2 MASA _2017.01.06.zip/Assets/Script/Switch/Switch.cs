﻿using UnityEngine;
using System.Collections;

public class Switch : MonoBehaviour {

    //プレイヤー1に反応
    public bool Player_1_Reaction;

    //プレイヤー2に反応
    public bool Player_2_Reaction;

    //プレイヤー1のマテリアル
    public Material Player_1_Material;

    //プレイヤー2のマテリアル
    public Material Player_2_Material;

    //ステージのマテリアル
    public Material Stage_Material;

    //セーブに対応したスイッチか
    public bool Save_Point_Switch;


    //Rigidbody対応
    private Rigidbody rb;

    //スイッチの反応動作
    private bool SwitchMove;

    //押された時のポジション
    private Vector3 SwitchMove_Position;

    //元々のポジション
    private Vector3 First_Position;

    //反応判定
    public bool Player_Action;     //プレイヤーが触った


    // Use this for initialization
    void Start () {

        //作動中の位置
        SwitchMove_Position = new Vector3(
            this.transform.position.x,
            this.transform.position.y-0.5f,
            this.transform.position.z
            );

        //初期位置保存
        First_Position = this.transform.position;

        rb = GetComponent<Rigidbody>();

        //マテリアルの変更
        //プレイヤー1に反応
        if (Player_1_Reaction == true)
        {
            this.GetComponent<Renderer>().material = Player_1_Material;
        }
        //プレイヤー2に反応
        if (Player_2_Reaction == true)
        {
            this.GetComponent<Renderer>().material = Player_2_Material;
        }
        //両方に反応
        if (Player_1_Reaction == true && Player_2_Reaction == true)
        {
            this.GetComponent<Renderer>().material = Stage_Material;
        }
    }
	
	// Update is called once per frame
	void Update () {

        //セーブについての信号の取得
        if (SwitchMove == true && Save_Point_Switch == true)
        {
            PlayerController.SAVE_POINT = new Vector3(
                                            this.transform.position.x,
                                            this.transform.position.y + 2.5f,
                                            this.transform.position.z
                                            );
        }


        //スイッチが動くアニメーション（ガタツキ修正されてない）
        if (this.transform.position.y >= First_Position.y)
        {
            //rb.constraints = RigidbodyConstraints.FreezePositionY;

            SwitchMove = false;

            Player_Action = false;
        }

        if (SwitchMove == true)
        {
            this.transform.position = new Vector3(
                                        this.transform.position.x,
                                        this.transform.position.y + 0.01f,
                                        this.transform.position.z
                                        );
        }
        else
        {
            //rb.constraints = RigidbodyConstraints.FreezePositionY;
        }

        if (this.transform.position.y < First_Position.y)
        {
            SwitchMove = true;
        }
	
	}

    /*void OnCollisionEnter(Collision other)
    {
        
    }*/

    void OnCollisionExit(Collision other)
    {
        Player_Action = false;
    }

    void OnCollisionStay(Collision other)
    {


        //プレイヤーに触れた時
        {
            if (other.gameObject.CompareTag("Player_1"))
            {
                if (Player_1_Reaction == true)
                {
                    Player_Action = true;
                }
                if (Player_1_Reaction == true && Player_2_Reaction == true)
                {
                    Player_Action = true;
                }
            }

            if (other.gameObject.CompareTag("Player_2"))
            {
                if (Player_2_Reaction == true)
                {
                    Player_Action = true;
                }
                if (Player_1_Reaction == true && Player_2_Reaction == true)
                {
                    Player_Action = true;
                }
            }
        }
    }
}
