﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

    //プレイヤーの指定
    public GameObject Player_1;
    public GameObject Player_2;

    //サブカメラ
    public Camera Player_Camera_1X;
    public Camera Player_Camera_0X;
    public Camera Player_Camera_1Y;
    public Camera Player_Camera_0Y;

    //三次元位置
    private static float THIS_POSITION_X;
    private static float THIS_POSITION_Y;
    private static float THIS_POSITION_Z;

    

    // Use this for initialization
    void Start () {
        THIS_POSITION_Z = Player_1.transform.position.z;
        
    }
	
	// Update is called once per frame
	void Update () {

        
    }
}
