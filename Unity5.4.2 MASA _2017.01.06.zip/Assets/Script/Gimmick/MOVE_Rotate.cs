﻿using UnityEngine;
using System.Collections;

public class MOVE_Rotate : MonoBehaviour {

    //回る速度
    public float Parent_Rotate_X;
    public float Parent_Rotate_Y;
    public float Parent_Rotate_Z;

    public float Child_Rotate_X;
    public float Child_Rotate_Y;
    public float Child_Rotate_Z;

    //信号を送るオブジェクト
    public GameObject Signal_Switch_Move;

    //動作設定
    public bool MOVE_ver1;
    public bool MOVE_ver2;

    //信号の真偽値
    public bool MOVE_BOOL;

	void Start () {

        
    }

    void Update()
    {

        //信号を送るオブジェクトがあるか
        if (Signal_Switch_Move == null)
        {
            MOVE_BOOL = false;
        }
        else
        {
            MOVE_BOOL = Signal_Switch_Move.GetComponent<Switch_Move>().Action_Bool;
        }

        //信号を受け取った時の処理
        if (MOVE_BOOL == false)
        {
            if (MOVE_ver1 == true)
            {
                //親オブジェクトの回転
                this.transform.Rotate(new Vector3(Parent_Rotate_X, Parent_Rotate_Y, Parent_Rotate_Z));

                //子オブジェクト取得
                foreach (Transform child in transform)
                {
                    //子オブジェクトの回転
                    child.transform.Rotate(new Vector3(Child_Rotate_X, Child_Rotate_Y, Child_Rotate_Z));
                }
            }

            if (MOVE_ver2 == true)
            {
                //親オブジェクトの回転
                this.transform.Rotate(new Vector3(Parent_Rotate_X, Parent_Rotate_Y, Parent_Rotate_Z));

                //子オブジェクト取得
                foreach (Transform child in transform)
                {
                    //子オブジェクトの回転
                    child.transform.Rotate(new Vector3(Child_Rotate_X, Child_Rotate_Y, Child_Rotate_Z));
                }
            }
        }
        else
        {
            //逆回転
            if (MOVE_ver2 == true)
            {
                //親オブジェクトの回転
                this.transform.Rotate(new Vector3(-Parent_Rotate_X, -Parent_Rotate_Y, -Parent_Rotate_Z));

                //子オブジェクト取得
                foreach (Transform child in transform)
                {
                    //子オブジェクトの回転
                    child.transform.Rotate(new Vector3(-Child_Rotate_X, -Child_Rotate_Y, -Child_Rotate_Z));
                }
            }
        }
    }
}
