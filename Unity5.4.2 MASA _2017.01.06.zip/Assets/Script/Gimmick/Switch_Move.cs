﻿using UnityEngine;
using System.Collections;

public class Switch_Move: MonoBehaviour {

    //信号を取得するオブジェクト
    public GameObject Signal_Object_1;
    public GameObject Signal_Object_2;

    //両方の信号を受け取った時に動くか
    public bool Both_Signal;

    //信号の真偽値
    public bool Action_Bool_1;//Signal_Object_1が反応した時
    public bool Action_Bool_2;//Signal_Object_2が反応した時

    //統合
    public bool Action_Bool;

    //セーブのグローバル信号
    public static bool Save_Point_MOVE;

    // Use this for initialization
    void Start () {

        Action_Bool = false;

	}
	
	// Update is called once per frame
	void Update () {


        //信号を取得
        if (Signal_Object_1 == null) { }
        else
        {
            Action_Bool_1 = Signal_Object_1.GetComponent<Switch>().Player_Action;
        }

        if (Signal_Object_2 == null) { }
        else
        {
            Action_Bool_2 = Signal_Object_2.GetComponent<Switch>().Player_Action;
        }

        //動作の真偽
        if ((Action_Bool_1 == true && Action_Bool_2 == true) && Both_Signal == true)
        {
            Action_Bool = true;
        }
        else if (Action_Bool_1 == true && Both_Signal == false || Action_Bool_2 == true && Both_Signal == false)
        {
            Action_Bool = true;
        }
        else
        {
            Action_Bool = false;
        }

    }
}
