﻿using UnityEngine;
using System.Collections;

public class Discrimination_Fall : MonoBehaviour {

    //プレイヤー1のマテリアル
    public Material Player_1_Material;

    //プレイヤー2のマテリアル
    public Material Player_2_Material;

    //信号を送るオブジェクト
    //設定した場合　信号を受け取った時除外対象を逆にする
    public GameObject Signal_Switch_Move;

    //プレイヤー1を識別する or プレイヤー2を識別する
    //プレイヤー1を除外　＝＝ true
    public bool Player_1_Discrimination;

    //信号の真偽値
    public bool MOVE_BOOL;

    // Use this for initialization
    void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {

        Discrimination();
    }

    //識別処理
    void Discrimination()
    {
        //オブジェクトの有無を確認
        if (Signal_Switch_Move == null)
        {
            MOVE_BOOL = false;
        }
        else
        {
            MOVE_BOOL = Signal_Switch_Move.GetComponent<Switch_Move>().Action_Bool;
        }

        //識別レイヤーの割り振り
        if (MOVE_BOOL == true)
        {

            if (Player_1_Discrimination == true)
            //プレイヤー1を除外しない
            {
                //プレイヤー1を除外する
                this.gameObject.layer = LayerMask.NameToLayer("Player1_Discrimination");

                this.GetComponent<Renderer>().material = Player_2_Material;
            }
            else//プレイヤー2を除外しない
            {
                //プレイヤー2を除外する
                this.gameObject.layer = LayerMask.NameToLayer("Player2_Discrimination");

                this.GetComponent<Renderer>().material = Player_1_Material;
            }
        }
        else
        {
            if (Player_1_Discrimination == true)
            {
                this.gameObject.layer = LayerMask.NameToLayer("Player2_Discrimination");

                this.GetComponent<Renderer>().material = Player_1_Material;
            }
            else
            {
                this.gameObject.layer = LayerMask.NameToLayer("Player1_Discrimination");

                this.GetComponent<Renderer>().material = Player_2_Material;
            }
        }
    }
}
