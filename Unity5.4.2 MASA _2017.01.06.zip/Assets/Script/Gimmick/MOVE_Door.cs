﻿using UnityEngine;
using System.Collections;

public class MOVE_Door : MonoBehaviour {

    //動かすオブジェクト
    public GameObject MOVE_FALL_OBJECT_1;
    public GameObject MOVE_FALL_OBJECT_2;



    //動かし方
    public bool MOVE_Door_ver1;//1　横に動かす
    public bool MOVE_Door_ver2;//2  真ん中を開ける様に動かす

    //動かし方　1
    public bool MOVE_Door_1_Move_Right; //壁を右に動かす？




    //自動で閉じるか
    public bool MOVE_Door_AutoRock;

    //動くスピード
    public float MOVE_SPEED;

    //扉が開く最大値
    public float MOVE_MAX;

    //扉が最大まで開いたか
    public bool MOVE_MAX_BOOL;




    //オブジェクト初期位置保存
    private Vector3 MOVE_FALL_OBJECT_1_FirstPosition;
    private Vector3 MOVE_FALL_OBJECT_2_FirstPosition;


    //信号を送るオブジェクト
    public GameObject Signal_Switch_Move;

    //信号の真偽値
    public bool MOVE_BOOL;

	void Start () {

        MOVE_FALL_OBJECT_1_FirstPosition = MOVE_FALL_OBJECT_1.transform.position;
        MOVE_FALL_OBJECT_2_FirstPosition = MOVE_FALL_OBJECT_2.transform.position;

        if (MOVE_Door_1_Move_Right == true && MOVE_Door_ver2 == true)
        {
            MOVE_Door_1_Move_Right = false;
        }

    }
	


	// Update is called once per frame
	void Update () {

        //信号を取得
        MOVE_BOOL = Signal_Switch_Move.GetComponent<Switch_Move>().Action_Bool;

        MAX();

        //信号が来たら
        if (MOVE_BOOL == true)
        {
            if (MOVE_MAX_BOOL == false)
            {
                //一つ目を起動するか
                if (MOVE_Door_ver1 == true)
                {
                    MOVE_DOOR_1();
                }
                //二つ目を起動するか
                else if (MOVE_Door_ver2 == true)
                {
                    MOVE_DOOR_2();
                }
            }
        }
        //自動閉鎖
        else if(MOVE_Door_AutoRock == true && MOVE_BOOL == false)
        {
            AutoRock();
        }
    }

    //最大値の処理
    void MAX()
    {
        //最大値を超えたとき
        if (MOVE_FALL_OBJECT_1_FirstPosition.x+ MOVE_MAX < MOVE_FALL_OBJECT_1.transform.position.x || MOVE_FALL_OBJECT_1_FirstPosition.x - MOVE_MAX > MOVE_FALL_OBJECT_1.transform.position.x)
        {
            MOVE_MAX_BOOL = true;
        }
        else if (MOVE_FALL_OBJECT_2_FirstPosition.x + MOVE_MAX < MOVE_FALL_OBJECT_2.transform.position.x || MOVE_FALL_OBJECT_2_FirstPosition.x - MOVE_MAX > MOVE_FALL_OBJECT_2.transform.position.x)
        {
            MOVE_MAX_BOOL = true;
        }
        else if (MOVE_FALL_OBJECT_1_FirstPosition.x + MOVE_MAX > MOVE_FALL_OBJECT_1.transform.position.x || MOVE_FALL_OBJECT_1_FirstPosition.x - MOVE_MAX < MOVE_FALL_OBJECT_1.transform.position.x)
        {
            MOVE_MAX_BOOL = false;
        }
        else if (MOVE_FALL_OBJECT_2_FirstPosition.x + MOVE_MAX > MOVE_FALL_OBJECT_2.transform.position.x || MOVE_FALL_OBJECT_2_FirstPosition.x - MOVE_MAX < MOVE_FALL_OBJECT_2.transform.position.x)
        {
            MOVE_MAX_BOOL = false;
        }
    }

    //一つ目の動き方
    void MOVE_DOOR_1()
    {
        //右に動くか
        if (MOVE_Door_1_Move_Right == true)
        {
            MOVE_FALL_OBJECT_1.transform.position = new Vector3(
                                                        MOVE_FALL_OBJECT_1.transform.position.x + MOVE_SPEED,
                                                        MOVE_FALL_OBJECT_1.transform.position.y,
                                                        MOVE_FALL_OBJECT_1.transform.position.z);
        }
        else
        {
            MOVE_FALL_OBJECT_1.transform.position = new Vector3(
                                                        MOVE_FALL_OBJECT_1.transform.position.x - MOVE_SPEED,
                                                        MOVE_FALL_OBJECT_1.transform.position.y,
                                                        MOVE_FALL_OBJECT_1.transform.position.z);
        }
    }

    void MOVE_DOOR_2()
    {
        //オブジェクトの位置関係の検索

        //オブジェクト2がオブジェクト1より右側にある
        if (MOVE_FALL_OBJECT_1.transform.position.x < MOVE_FALL_OBJECT_2.transform.position.x)
        {
            //オブジェクト1が左に移動
            MOVE_FALL_OBJECT_1.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_1.transform.position.x - MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_1.transform.position.y,
                                                    MOVE_FALL_OBJECT_1.transform.position.z);

            //オブジェクト2が右に移動
            MOVE_FALL_OBJECT_2.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_2.transform.position.x + MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_2.transform.position.y,
                                                    MOVE_FALL_OBJECT_2.transform.position.z);
        }
        //オブジェクト1がオブジェクト2より右側にある
        else if (MOVE_FALL_OBJECT_1.transform.position.x > MOVE_FALL_OBJECT_2.transform.position.x)
        {
            //オブジェクト1が右に移動
            MOVE_FALL_OBJECT_1.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_1.transform.position.x + MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_1.transform.position.y,
                                                    MOVE_FALL_OBJECT_1.transform.position.z);

            //オブジェクト2が左に移動
            MOVE_FALL_OBJECT_2.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_2.transform.position.x - MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_2.transform.position.y,
                                                    MOVE_FALL_OBJECT_2.transform.position.z);
        }

    }

    //自動閉鎖
    void AutoRock()
    {
        //オブジェクト1に関して
        //右側に動いていれば
        if (MOVE_FALL_OBJECT_1.transform.position.x > MOVE_FALL_OBJECT_1_FirstPosition.x + 0.1f)
        {
            MOVE_FALL_OBJECT_1.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_1.transform.position.x - MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_1.transform.position.y,
                                                    MOVE_FALL_OBJECT_1.transform.position.z);
        }
        //左側に動いていれば
        else if (MOVE_FALL_OBJECT_1.transform.position.x < MOVE_FALL_OBJECT_1_FirstPosition.x - 0.1f)
        {
            MOVE_FALL_OBJECT_1.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_1.transform.position.x + MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_1.transform.position.y,
                                                    MOVE_FALL_OBJECT_1.transform.position.z);
        }
        //同じ位置にいれば
        else if (MOVE_FALL_OBJECT_1.transform.position.x == MOVE_FALL_OBJECT_1_FirstPosition.x)
        {
            MOVE_FALL_OBJECT_1.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_1_FirstPosition.x,
                                                    MOVE_FALL_OBJECT_1_FirstPosition.y,
                                                    MOVE_FALL_OBJECT_1_FirstPosition.z
                                                    );
        }

        //オブジェクト2に関して
        //右側に動いていれば
        if (MOVE_FALL_OBJECT_2.transform.position.x > MOVE_FALL_OBJECT_2_FirstPosition.x + 0.1f)
        {
            MOVE_FALL_OBJECT_2.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_2.transform.position.x - MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_2.transform.position.y,
                                                    MOVE_FALL_OBJECT_2.transform.position.z);
        }
        //左に動いていれば
        else if (MOVE_FALL_OBJECT_2.transform.position.x < MOVE_FALL_OBJECT_2_FirstPosition.x - 0.1f)
        {
            MOVE_FALL_OBJECT_2.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_2.transform.position.x + MOVE_SPEED,
                                                    MOVE_FALL_OBJECT_2.transform.position.y,
                                                    MOVE_FALL_OBJECT_2.transform.position.z);
        }
        //同じ位置にいれば
        else if (MOVE_FALL_OBJECT_2.transform.position.x == MOVE_FALL_OBJECT_2_FirstPosition.x)
        {
            MOVE_FALL_OBJECT_2.transform.position = new Vector3(
                                                    MOVE_FALL_OBJECT_2_FirstPosition.x,
                                                    MOVE_FALL_OBJECT_2_FirstPosition.y,
                                                    MOVE_FALL_OBJECT_2_FirstPosition.z
                                                    );
        }
    }
}
